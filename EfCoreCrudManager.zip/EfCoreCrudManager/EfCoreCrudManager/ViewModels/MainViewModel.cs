﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;
using EfCoreCrudManager.Data;
using EfCoreCrudManager.Models;

namespace EfCoreCrudManager.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private AppDbContext db; 


        private ObservableCollection<Product> items;
        public ObservableCollection<Product> Items
        {
            get { return items; }
            set
            {
                items = value;
                OnPropertyChanged("Items");
            }
        }


        private Product selectedItem;
        public Product SelectedItem
        {
            get { return selectedItem; }
            set
            {
                selectedItem = value;
                OnPropertyChanged("SelectedItem");

     
                if (value != null)
                {
                    Field1 = value.Name;
                    Field2 = value.Price;
                }
            }
        }

        private string field1;
        public string Field1
        {
            get { return field1; }
            set
            {
                field1 = value;
                OnPropertyChanged("Field1");
            }
        }

        private decimal field2;
        public decimal Field2
        {
            get { return field2; }
            set
            {
                field2 = value;
                OnPropertyChanged("Field2");
            }
        }

        public ICommand AddCommand { get; set; }
        public ICommand UpdateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public MainViewModel()
        {
            db = new AppDbContext();

            db.Database.EnsureCreated();

            LoadItems();

            AddCommand = new RelayCommand(AddItem, CanAddItem);
            UpdateCommand = new RelayCommand(UpdateItem, CanUpdateItem);
            DeleteCommand = new RelayCommand(DeleteItem, CanDeleteItem);
        }

        private void LoadItems()
        {
            var list = db.Products.ToList();
            Items = new ObservableCollection<Product>(list);
        }
        private bool CanAddItem(object param)
        {
            return !string.IsNullOrWhiteSpace(Field1) && Field2 > 0;
        }

        private void AddItem(object param)
        {
            try
            {
                Product newProduct = new Product
                {
                    Name = Field1,
                    Price = Field2
                };

                db.Products.Add(newProduct);
                db.SaveChanges();

                Items.Add(newProduct);

           Field1 = "";
                Field2 = 0;

                MessageBox.Show("Товар добавлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private bool CanUpdateItem(object param)
        {
            return SelectedItem != null && !string.IsNullOrWhiteSpace(Field1) && Field2 > 0;
        }


        private void UpdateItem(object param)
        {
            try
            {
                SelectedItem.Name = Field1;
                SelectedItem.Price = Field2;

                db.Products.Update(SelectedItem);
                db.SaveChanges();


                int index = Items.IndexOf(SelectedItem);
                Items[index] = SelectedItem;

                MessageBox.Show("Товар обновлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                Field1 = "";
                Field2 = 0;
                SelectedItem = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool CanDeleteItem(object param)
        {
            return SelectedItem != null;
        }

        private void DeleteItem(object param)
        {
            MessageBoxResult result = MessageBox.Show("Точно удалить?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    db.Products.Remove(SelectedItem);
                    db.SaveChanges();

                    Items.Remove(SelectedItem);

                    Field1 = "";
                    Field2 = 0;

                    MessageBox.Show("Товар удален!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }
    }
}