﻿using EfCoreCrudManager.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace EfCoreCrudManager.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Product> Products { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;Database=MyProductDB;Trusted_Connection=True;TrustServerCertificate=True");
        }
    }
}