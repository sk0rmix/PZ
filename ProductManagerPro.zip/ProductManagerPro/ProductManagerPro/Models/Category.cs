﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ProductManagerPro.Models
{
    public class Category
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public ICollection<Product> Products { get; set; } = new List<Product>();
    }
}