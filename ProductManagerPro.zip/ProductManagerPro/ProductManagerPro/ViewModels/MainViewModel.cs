﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;
using ProductManagerPro.Data;
using ProductManagerPro.Models;

namespace ProductManagerPro.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly ApplicationDbContext _context;
        private bool _isClearing;

        public MainViewModel()
        {
            _context = new ApplicationDbContext();
            _context.Database.Migrate();

            Products = new ObservableCollection<Product>();
            Categories = new ObservableCollection<Category>();

            LoadProducts();
            LoadCategories();

            AddCommand = new RelayCommand(_ => AddProduct(), _ => CanAddOrUpdate());
            UpdateCommand = new RelayCommand(_ => UpdateProduct(), _ => SelectedProduct != null);
            DeleteCommand = new RelayCommand(_ => DeleteProduct(), _ => SelectedProduct != null);
        }

        public ObservableCollection<Product> Products { get; set; }
        public ObservableCollection<Category> Categories { get; set; }

        private Product? _selectedProduct;
        public Product? SelectedProduct
        {
            get => _selectedProduct;
            set
            {
                if (_isClearing) return;

                _selectedProduct = value;
                if (value != null && !_isClearing)
                {
                    ProductName = value.Name;
                    ProductPrice = value.Price;
                    SelectedCategoryId = value.CategoryId;
                }
                OnPropertyChanged();
                (UpdateCommand as RelayCommand)?.RaiseCanExecuteChanged();
                (DeleteCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }

        private string _productName = string.Empty;
        public string ProductName
        {
            get => _productName;
            set
            {
                _productName = value;
                OnPropertyChanged();
                (AddCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }

        private decimal _productPrice;
        public decimal ProductPrice
        {
            get => _productPrice;
            set
            {
                _productPrice = value;
                OnPropertyChanged();
                (AddCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }

        private int _selectedCategoryId;
        public int SelectedCategoryId
        {
            get => _selectedCategoryId;
            set
            {
                _selectedCategoryId = value;
                OnPropertyChanged();
                (AddCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }

        public ICommand AddCommand { get; }
        public ICommand UpdateCommand { get; }
        public ICommand DeleteCommand { get; }

        private bool CanAddOrUpdate()
        {
            return !string.IsNullOrWhiteSpace(ProductName) && ProductPrice > 0 && SelectedCategoryId > 0;
        }

        private void LoadProducts()
        {
            Products.Clear();
            var productsFromDb = _context.Products.Include(p => p.Category).OrderBy(p => p.Id).ToList();
            foreach (var p in productsFromDb)
                Products.Add(p);
        }

        private void LoadCategories()
        {
            Categories.Clear();
            var categoriesFromDb = _context.Categories.OrderBy(c => c.Name).ToList();
            foreach (var c in categoriesFromDb)
                Categories.Add(c);

            if (Categories.Any() && SelectedCategoryId == 0)
                SelectedCategoryId = Categories.First().Id;
        }

        private void AddProduct()
        {
            if (!CanAddOrUpdate())
            {
                MessageBox.Show("Заполните название и цену товара!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var newProduct = new Product
                {
                    Name = ProductName.Trim(),
                    Price = ProductPrice,
                    CategoryId = SelectedCategoryId
                };

                _context.Products.Add(newProduct);
                _context.SaveChanges();
                _context.Entry(newProduct).Reference(p => p.Category).Load();
                Products.Add(newProduct);
                ClearForm();
                MessageBox.Show("Товар успешно добавлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateProduct()
        {
            if (SelectedProduct == null) return;

            try
            {
                SelectedProduct.Name = ProductName.Trim();
                SelectedProduct.Price = ProductPrice;
                SelectedProduct.CategoryId = SelectedCategoryId;

                _context.Products.Update(SelectedProduct);
                _context.SaveChanges();

                var index = Products.IndexOf(SelectedProduct);
                Products.RemoveAt(index);
                Products.Insert(index, SelectedProduct);

                ClearForm();
                MessageBox.Show("Товар успешно обновлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteProduct()
        {
            if (SelectedProduct == null) return;

            if (MessageBox.Show($"Удалить товар \"{SelectedProduct.Name}\"?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                _context.Products.Remove(SelectedProduct);
                _context.SaveChanges();
                Products.Remove(SelectedProduct);
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearForm()
        {
            _isClearing = true;

            ProductName = string.Empty;
            ProductPrice = 0;
            if (Categories.Any())
                SelectedCategoryId = Categories.First().Id;
            _selectedProduct = null;
            OnPropertyChanged(nameof(SelectedProduct));

            _isClearing = false;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}